<?php
return array(
	'db_name'	=> 'honey',
	'host' 		=> 'localhost',
	'username' 	=> 'root',
	'password' 	=> '' 
);